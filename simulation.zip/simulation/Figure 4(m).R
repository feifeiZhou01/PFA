
library(snowfall)  
library(parallel)
library(Matrix)
library(MASS)
##########################
path <- "C:/PFA_code/TT=1000N=2000/m/"
set.seed(0)
n <- 100                                   #sample
seed <- c(1:n)                           
rho <- 0.5; beta <- 0.2; theta <- 1
J <- 10
r <- 3
mm <- c(10,15,20)
em_Lam <- result <- list()
DL_4 <- DF_4 <- DC_exc <- DL_7 <- DF_7 <- DC_exc1 <- DL_1 <- DF_1 <- DC <- DL_2 <- DF_2 <- DC_Fan <- DL_3 <- DF_3 <- DC_DEn <- matrix(0,n,length(mm))
DL_5 <- DF_5 <- DC_Gao1 <- matrix(0,n,length(mm))
t_DEn <- t_PCA <- t_PFA <- t_En <- t_Fan <-  t_Gao1 <- matrix(0,n,length(mm))
DL_7_a <- DF_7_a <- DC_exc1_a <- t_En_a <- lapply(1:3,function(x) x = matrix(0,n,length(mm)))
out <- NULL
TT <- 1000
N <- 2000
Lambda <- L <- Lam_em <- matrix(0,N,r)
X <- matrix(0,TT,N)


  for(i in 1:n){#i=2
    for(j in 1:length(mm)){  
      
    m <- mm[j]
    em <- m+1
    stepp <- c(N-m*ceiling(N/(m+1)),rep(ceiling(N/(m+1)),m));stepp #N_i 
    
    dat <- data(TT,N,r,J,rho,beta,theta) 
    XX <- dat$X    
    L <- dat$Lambda
    set.seed(seed[i])
    index <- sample(1:N) #index <- c(1:N)
    for(l in 1:N){
      X[,l] <- XX[,index[l]]
      Lambda[l,] <- L[index[l],]
    }
    
    #PCA
    a <- proc.time()
    out <- est_PCA1(X,r)
    lam_T <- out$Lambda_hat
    FF <- out$F_hat
    b <- proc.time()
    t_PCA[i] <- (b-a)["elapsed"]
    DL_1[i,j] <- D(Lambda,lam_T,r)
    DF_1[i,j] <- D(dat$FF,FF,r)
    DC[i,j] <- norm(FF%*%t(lam_T)-dat$FF%*%t(Lambda),"F")/sqrt(TT*N)
    
    #HFA
    a <- proc.time()
    Gao1 <- HFA(X,r,m)
    b <- proc.time()
    t_Gao1[i,j] <- (b-a)["elapsed"]
    closeAllConnections()
    DL_5[i,j] <- D(Lambda,Gao1$ABH,r)
    DF_5[i,j] <- D(dat$FF,Gao1$Fht,r)
    DC_Gao1[i,j] <- norm(Gao1$Fht%*%t(Gao1$ABH)-dat$FF%*%t(Lambda),"F")/sqrt(TT*N)


    #PFA
    a <- proc.time()
    PF <- PFA(X,r,m,L,stepp)
    Lam <- PF$Lam
    FF <- PF$FF
    b <- proc.time()
    t_PFA[i,j] <- (b-a)["elapsed"]
    closeAllConnections()
    DL_4[i,j] <- D(Lambda,Lam,r)
    DF_4[i,j] <- D(dat$FF,FF,r)
    DC_exc[i,j] <- norm(FF%*%t(Lam)-dat$FF%*%t(Lambda),"F")/sqrt(TT*N)

    #En-PFA
    a <- proc.time()
    En <- En_PFA(X,r,m,aa=1,Lam_em)
    Lam_em <- En$Lam_em
    FF_em <-  En$FF_em
    b <- proc.time()
    t_En[i,j] <- (b-a)["elapsed"]
    DL_7[i,j] <- D(Lam_em,Lambda,r)
    DF_7[i,j] <- D(FF_em,dat$FF,r)
    DC_exc1[i,j] <- norm(FF_em%*%t(Lam_em)-dat$FF%*%t(Lambda),"F")/sqrt(TT*N)
    closeAllConnections()

    #DP
    a <- proc.time()
    Fan <- DPCA(X,r,em,TT)
    Lam_D <- Fan$Lam_D
    F_D <- Fan$FF_D
    b <- proc.time()
    t_Fan[i] <- (b-a)["elapsed"]
    DL_2[i,j] <- D(Lambda,Lam_D,r)
    DF_2[i,j] <- D(dat$FF,F_D,r)
    DC_Fan[i,j] <- norm(F_D%*%t(Lam_D)-dat$FF%*%t(Lambda),"F")/sqrt(TT*N)


    ##En-PFA-aa

    for(a in 1:3){
      aa <- c(0.1,0.25,0.5)[a]
      em <- aa*(m+1)
      temp <- rep(0,em) #time
      b <- proc.time()
      En <- En_PFA(X,r,m,aa,Lam_em)
      Lam_em <- En$Lam_em
      FF_em <-  En$FF_em
      c <- proc.time()
      t_En_a[[a]][i,j] <- (c-b)["elapsed"]
      DL_7_a[[a]][i,j] <- D(Lam_em,Lambda,r)
      DF_7_a[[a]][i,j] <- D(FF_em,dat$FF,r)
      DC_exc1_a[[a]][i,j] <- norm(FF_em%*%t(Lam_em)-dat$FF%*%t(Lambda),"F")/sqrt(TT*N)
      closeAllConnections()
    }

    
    # #DEn-PFA
    # em_Lam <- list()
    # a <- proc.time()
    # DEn <- DEn_PFA(X,TT,N,r,em,k3,stepp,Lam_em)
    # Lam_em <- DEn$Lam_em
    # FF_em <- DEn$FF_em
    # b <- proc.time()
    # t_DEn[i] <- (b-a)["elapsed"]
    # DL_3[i] <- D(Lam_em,Lambda,r)
    # DF_3[i] <- D(FF_em,dat$FF,r)
    # DC_DEn[i] <- norm(FF_em%*%t(Lam_em)-dat$FF%*%t(Lambda),"F")/sqrt(TT*N)
    # closeAllConnections()
  
  }
    print(i)
  }

DL <- rbind(rbind(apply(DL_1,2,mean),apply(DL_2,2,mean),apply(DL_3,2,mean),apply(DL_4,2,mean),apply(DL_5,2,mean),apply(DL_7,2,mean)),
            Reduce(rbind,lapply(DL_7_a,function(x) apply(x,2,mean))))
DF <- rbind(rbind(apply(DF_1,2,mean),apply(DF_2,2,mean),apply(DF_3,2,mean),apply(DF_4,2,mean),apply(DF_5,2,mean),apply(DF_7,2,mean)),
            Reduce(rbind,lapply(DF_7_a,function(x) apply(x,2,mean))))
CC <- rbind(rbind(apply(DC,2,mean),apply(DC_Fan,2,mean),apply(DC_DEn,2,mean),apply(DC_exc,2,mean),apply(DC_Gao1,2,mean),apply(DC_exc1,2,mean)),
            Reduce(rbind,lapply(DC_exc1_a,function(x) apply(x,2,mean))))

Time <- rbind(rbind(apply(t_PCA,2,mean),apply(t_Fan,2,mean),apply(t_DEn,2,mean),apply(t_PFA,2,mean),apply(t_Gao1,2,mean),apply(t_En,2,mean)),
            Reduce(rbind,lapply(t_En_a,function(x) apply(x,2,mean))))

names <- c("PCA","DP","DEn","PFA","HFA",paste0("En-PFA",c(1,0.1,0.25,0.5)))
rownames(DL) <- rownames(DF) <- rownames(CC) <- rownames(Time) <- names
colnames(DL) <- colnames(DF) <- colnames(CC) <- colnames(Time) <- mm


m <- NULL
for(j in 1:length(mm)){#j <- 1
  out <- cbind(DL[,j],DF[,j],CC[,j],Time[,j],rep(mm[j],length(names)))
  m <- rbind(m,out)
  L <- cbind(DL_1[,j],DL_2[,j],DL_3[,j],DL_4[,j],DL_5[,j],DL_7[,j],DL_7_a[[1]][,j],DL_7_a[[2]][,j],DL_7_a[[3]][,j])
  DDF <- cbind(DF_1[,j],DF_2[,j],DF_3[,j],DF_4[,j],DF_5[,j],DF_7[,j],DF_7_a[[1]][,j],DF_7_a[[2]][,j],DF_7_a[[3]][,j])
  C <- cbind(DC[,j],DC_Fan[,j],DC_DEn[,j],DC_exc[,j],DC_Gao1[,j],DC_exc1[,j],DC_exc1_a[[1]][,j],DC_exc1_a[[2]][,j],DC_exc1_a[[3]][,j])
  time <- cbind(t_PCA[,j],t_Fan[,j],t_DEn[,j],t_PFA[,j],t_Gao1[,j],t_En[,j],t_En_a[[1]][,j],t_En_a[[2]][,j],t_En_a[[3]][,j])
  
  
  write.csv(out,paste0(path,"TT",TT,"N",N,"J",J,"_rho",rho,"m",mm[j],"out.csv"))
  write.csv(L,paste0(path,"TT",TT,"N",N,"J",J,"_rho",rho,"m",mm[j],"DL.csv"))
  write.csv(DDF,paste0(path,"TT",TT,"N",N,"J",J,"_rho",rho,"m",mm[j],"DF.csv"))
  write.csv(C,paste0(path,"TT",TT,"N",N,"J",J,"_rho",rho,"m",mm[j],"CC.csv"))
  write.csv(time,paste0(path,"TT",TT,"N",N,"J",J,"_rho",rho,"m",mm[j],"time.csv"))
  
}
colnames(m) <- c("DL","DF","CC","time","m")
write.csv(m,paste0(path,"TT",TT,"N",N,"J",J,"_rho",rho,"mm.csv"))
m





