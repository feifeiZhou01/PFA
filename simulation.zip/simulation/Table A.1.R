# weak factors
data <- function(TT,N,r,J,rho,beta,theta,SNR){
  E <- matrix(0,TT,N)
  v <- mvrnorm(TT, rep(0, N), diag(1,N))
  betav <- apply(cbind(1:N),1,function(i) beta*rowSums(as.matrix(v[,pmax(1,i-J):pmin(i+J,N)])))
  E[1,] <- (1-beta)*v[1,]+betav[1,]
  for (t in 2:TT)E[t,] <- rho*E[t-1,]+(1-beta)*v[t,]+betav[t,]
  U <- sqrt((1-rho^2)/(1+2*J*beta^2))*E
  U <- U%*%diag(1/sqrt(diag(t(U)%*%U)/TT)) #a <- t(U)%*%U/TT 
  L <- as.matrix(sqrt(N)*Fregularize(matrix(rnorm(N*r,0,1),N,r),r)) 
  FF <- as.matrix(Lregularize(mvrnorm(TT, rep(0, r), diag(c(1,1,SNR))),r))
  X <- FF%*%t(L)+sqrt(theta)*U
  X <- X - matrix(rep(apply(X,2,mean),TT),nrow=TT,byrow=TRUE)
  return(list(FF=FF,Lambda=L,X=X))
}
########################################
code_dir <- "C:/PFA_code/TT=1000N=2000/weak_r/"
all <- NULL
library(snowfall)  
library(parallel)
library(Matrix)
library(MASS)
#SNR <- 0.15
set.seed(0)
n <- 100
seed <- c(1:n)
TT <- 1000
N <- 2000   
rho <- 0.5; beta <- 0.2; theta <- 1
J <- 15 #10 #
r <- 3
r_FFA <- r_plus <- r_HFA <- rep(0,n)
X <- matrix(0,TT,N)
factor <- NULL
m <- 19

for(SNR in c(0.6,0.45,0.3,0.15)){ #SNR <- 0.15
  #PFA
  k3 <- m 
  ra <- numeric(k3)
  stepp <- c(N-m*ceiling(N/(m+1)),rep(ceiling(N/(m+1)),m))
  r_ratio <- matrix(0,n,k3)
  
  #HFA
  step2 <- stepp;step2
  k4 <- m+1
  r_Gao <- matrix(0,n,k4)
  
  for(l in 1:n){#l <-1
    dat <- data(TT,N,r,J,rho,beta,theta,SNR)    #weak+strong factors
    XX <- dat$X 
    set.seed(seed[l])
    index <- sample(1:N)
    for(j in 1:N){
      X[,j] <- XX[,index[j]]
    }
    
    #VER
    r_ratio[l,] <- r_PFA(X,k3,stepp)
    r_FFA[l] <- get_mode(r_ratio[l,])
    
    #TVER
    r_plus[l] <- r_PFA_plus(X,k3,stepp)
    
    
    #HFA
    cl <- makeCluster(k4)
    clusterSetRNGStream(cl)
    clusterExport(cl,c("X","TT","step2","k4"))
    result <- parSapply(cl,1:k4,function(k){
      end <- sum(step2[1:k])
      x <- X[ ,(end-step2[k]+1):end]
      ppi <- ncol(x)
      K=ceiling(ppi/3)
      rn=numeric(K)
      sdt=t(x)
      M=t(sdt)%*%sdt
      G=sqrt(TT)*eigen(M)$vectors
      for (j in 1:K){
        rn[j]=log(norm(t(sdt)-G[,1:j]%*%t(G[,1:j])%*%t(sdt)/TT,type=c("F"))^2/(ppi*TT))+j*(ppi+TT)/(ppi*TT)*log(ppi*TT/(ppi+TT))
      }
      rih=which.min(rn)           #the number of factors on each partition
      Ght=G[,1:rih]               #factors on each partition
      return(list("FF_hat" = Ght,"rih"=rih))
    })
    stopCluster(cl)
    FF_hat <- result["FF_hat", ]
    rhit <- unlist(result["rih", ])
    rtt=sum(rhit);rtt
    #step2 PCA
    GG=FF_hat[[1]]
    for (jj in 2:k4){
      GG=cbind(GG,FF_hat[[jj]])#TT, m*ri dim(GG)
    }
    MM=GG%*%t(GG)
    dv=eigen(MM)$values
    rr=which.min(dv[2:(rtt/2)]/dv[1:(rtt/2-1)])
    r_Gao[l,] <- rhit
    r_HFA[l] <- rr
    closeAllConnections()
    print(l)
  }
  FFA_mode <- cbind(r_ratio,r_FFA)
  HFA_mode <- cbind(r_Gao,r_HFA)
  FFA <- t(apply(FFA_mode,2,function(x){paste0(mean(x),"(",sum(x<r),"|",sum(x>r),")")}))
  HFA <- t(apply(HFA_mode,2,function(x){paste0(mean(x),"(",sum(x<r),"|",sum(x>r),")")}))
  write.csv(rbind(FFA_mode,FFA),paste0(code_dir,"/FFA_m",m,"_J",J,"_rho",rho,"SNR=",SNR,".csv"))
  write.csv(rbind(HFA_mode,HFA),paste0(code_dir,"/HFA_m",m,"_J",J,"_rho",rho,"SNR=",SNR,".csv"))
  
  out <- cbind(paste0(mean(r_FFA),"(",sum(r_FFA<r),"|",sum(r_FFA>r),")"),
               paste0(mean(r_plus),"(",sum(r_plus<r),"|",sum(r_plus>r),")"),
               paste0(mean(r_HFA),"(",sum(r_HFA<r),"|",sum(r_HFA>r),")"))
  #, paste0(mean(r_t),"(",sum(r_t<r),"|",sum(r_t>r),")"))
  factor <- rbind(factor,out)
}

colnames(factor) <- c("VER","TVER1","HFA")
rownames(factor) <- c(0.6,0.45,0.3,0.15)
factor
path <- paste0(code_dir,"TT=",TT,"N=",N,"_J",J,"_rho",rho, "SNR1.csv")
write.csv(factor,path)

