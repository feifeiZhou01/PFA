
###################Function: data generation 
#----------------------------------------------------------------------------
library(MASS)
library(mvtnorm)
#strong factors 
data <- function(TT,N,r,J,rho,beta,theta){
  E <- matrix(0,TT,N)
  v <- mvrnorm(TT, rep(0, N), diag(1,N))
  betav <- apply(cbind(1:N),1,function(i) beta*rowSums(as.matrix(v[,pmax(1,i-J):pmin(i+J,N)])))
  E[1,] <- (1-beta)*v[1,]+betav[1,]
  for (t in 2:TT)E[t,] <- rho*E[t-1,]+(1-beta)*v[t,]+betav[t,]
  U <- sqrt((1-rho^2)/(1+2*J*beta^2))*E
  L <- as.matrix(sqrt(N)*Fregularize(matrix(rnorm(N*r,0,1),N,r),r)) 
  FF <- as.matrix(Lregularize(mvrnorm(TT, rep(0, r), diag(1,r)),r))
  X <- FF%*%t(L)+sqrt(theta)*U
  X <- X - matrix(rep(apply(X,2,mean),TT),nrow=TT,byrow=TRUE)
  return(list(FF=FF,Lambda=L,X=X))
}

# weak factors
data <- function(TT,N,r,J,rho,beta,theta,SNR){
  E <- matrix(0,TT,N)
  v <- mvrnorm(TT, rep(0, N), diag(1,N))
  betav <- apply(cbind(1:N),1,function(i) beta*rowSums(as.matrix(v[,pmax(1,i-J):pmin(i+J,N)])))
  E[1,] <- (1-beta)*v[1,]+betav[1,]
  for (t in 2:TT)E[t,] <- rho*E[t-1,]+(1-beta)*v[t,]+betav[t,]
  U <- sqrt((1-rho^2)/(1+2*J*beta^2))*E
  U <- U%*%diag(1/sqrt(diag(t(U)%*%U)/TT)) #a <- t(U)%*%U/TT 
  L <- as.matrix(sqrt(N)*Fregularize(matrix(rnorm(N*r,0,1),N,r),r)) 
  FF <- as.matrix(Lregularize(mvrnorm(TT, rep(0, r), diag(c(1,1,SNR))),r))
  X <- FF%*%t(L)+sqrt(theta)*U
  X <- X - matrix(rep(apply(X,2,mean),TT),nrow=TT,byrow=TRUE)
  return(list(FF=FF,Lambda=L,X=X))
}

############### Function: estimation methods
#----------------------------------------------------------------------------
em_splice <- function(Lambda_hat,Lam,k,k3,stepp){ 
  step <- stepp[-k]                                             #overlap <- stepp[k]
  over <- c((sum(stepp[1:k])-stepp[k]+1):sum(stepp[1:k]))       #index_overlap
  ind <- c(1:N)[-over]
  splice <- c(over,ind[1:step[1]])
  Lam[splice,] <- Lambda_hat[[1]]
  for(j in 2:k3) Lam[ind[(sum(step[1:(j-1)])+1):sum(step[1:j])],] <- Lambda_hat[[j]][(stepp[k]+1):(stepp[k]+step[j]),]%*%apply(Lambda_hat[[1]][1:stepp[k],],2,function(y) h <- solve(t(Lambda_hat[[j]][1:stepp[k],])%*% Lambda_hat[[j]][1:stepp[k],])%*%t(Lambda_hat[[j]][1:stepp[k],])%*%y)
  return(Lam)
}

#### Lambda
est_PCA1 <- function(X,r){
  N <- ncol(X)
  TT <- nrow(X)
  eig_X <- eigen(t(X)%*%X/(N*TT))
  Lambda_hat <- sqrt(N)*as.matrix(eig_X$vectors[,1:r],nrow=N)
  FF_hat <- X%*%Lambda_hat/N
  return(list(F_hat=FF_hat,Lambda_hat= Lambda_hat))
}
#### FF
est_PCA <- function(X,r){
  N <- ncol(X)
  TT <- nrow(X)
  FF_hat <- sqrt(TT)*as.matrix(eigen(X%*%t(X)/(N*TT))$vectors[,1:r],nrow=T)
  Lambda_hat=t(X)%*%FF_hat/TT
  return(list(F_hat=FF_hat,Lambda_hat= Lambda_hat))
}

#----------------------------------------------------------------------------

################ Function:  Orthogonalize and diagonalize

#----------------------------------------------------------------------------

library("quantreg")
library("MASS")
library("pracma") #gramSchmidt


Fregularize <- function(F,r){
  
  if(r>1){
    Freg <- Orthogonalize(F)
  } else{
    Freg <- F/sqrt(sum(F^2))
  }
  return(Freg)
}

Lregularize <- function(L,r){
  
  if(r>1){
    svdL  <- svd(L)
    svdLD <- diag(svdL$d)
    Lreg <- (svdL$u)%*%svdLD
    return(Lreg)
  } else{
    return(L)
  }
}

Orthogonalize <- function(Z){
  gs <- gramSchmidt(Z)
  Q <- gs$Q
  return(Q)
}

################ Function:  measure
#----------------------------------------------------------------------------
D <- function(Ahat,A,r){
  P1 <- Ahat%*%solve(t(Ahat)%*%Ahat)%*%t(Ahat)
  P2 <- A%*%solve(t(A)%*%A)%*%t(A)
  DA <- sqrt(1-sum(diag(P1%*%P2))/r)
  return(DA)
}
#----------------------------------------------------------------------------
aa <- 1
Lam_em <- matrix(0,N,r)
En_PFA <- function(X,r,m,aa,Lam_em){
  em_Lam <- list()
  N <- ncol(X)
  em <- aa*(m+1)
  stepp <- c(N-m*ceiling(N/(m+1)),rep(ceiling(N/(m+1)),m));stepp #N_i
  for(k in 1:em){# k=1
    cl <- makeCluster(m)
    clusterSetRNGStream(cl)
    clusterExport(cl,c("est_PCA1","X","r","m","stepp","N"))
    tem_Lam <- parSapply(cl,1:m,function(i, k){#i=1
      step <- stepp[-k]                                            
      over <- c((sum(stepp[1:k])-stepp[k]+1):sum(stepp[1:k]))
      ind <- c(1:N)[-over]
      out1 <- est_PCA1(X[,c(over,ind[(sum(step[1:i])-step[i]+1):sum(step[1:i])])],r)
      Lambda <- out1$Lambda_hat
      return(list("Lambda"=Lambda))
    },k = k)
    stopCluster(cl)
    em_Lam[[k]] <- em_splice(tem_Lam,Lam_em,k,m,stepp)
  }
  align_emLam <- do.call(cbind,em_Lam)#;head(align_emLam)
  Lam_em <- sqrt(N)*(svd(align_emLam)$u)[,1:r] 
  FF_em <- X%*%Lam_em%*%solve(t(Lam_em)%*%Lam_em)
  return(list("Lam_em" = Lam_em, "FF_em" = FF_em))
}
PFA <- function(X,r,m,L,stepp){
  N <- ncol(X)
  step <- stepp[2]
  overlap <- stepp[1]
  cl <- makeCluster(m)
  clusterSetRNGStream(cl)
  clusterExport(cl,c("est_PCA1","X","r","m"))
  tem_Lam <- parSapply(cl,1:m,function(i,step,overlap){#i=1
    end <- overlap+i*step
    out1 <- est_PCA1(X[,c(1:overlap,(end-step+1):end)],r)
    Lambda <- out1$Lambda_hat
    return(list("Lambda"=Lambda))
  },step,overlap)
  stopCluster(cl)
  Lam <- em_splice(tem_Lam,L,k=1,m,stepp)
  FF <- X%*%Lam%*%solve(t(Lam)%*%Lam)
  return(list("Lam" = Lam, "FF" = FF))
}


HFA <- function(X,r,m){
  N <- ncol(X)
  stepp <- c(N-m*ceiling(N/(m+1)),rep(ceiling(N/(m+1)),m))
  k4 <- length(stepp)
  cl <- makeCluster(m+1)
  clusterSetRNGStream(cl)
  clusterExport(cl,c("est_PCA","X","r"))
  result <- parSapply(cl,1:(m+1),function(k,stepp){#k=1
    end <- sum(stepp[1:k])
    out <- est_PCA(X[ ,(end-stepp[k]+1):end],r)
    Lambda_hat <- out$Lambda_hat
    FF_hat <- out$F_hat
    return(list("Lambda_hat" = Lambda_hat,"FF_hat" = FF_hat))
  },stepp)
  stopCluster(cl)
  Lambda_hat2 <- result["Lambda_hat", ]
  FF_hat <- result["FF_hat", ]
  AAht <- Lambda_hat2[[1]]         ##对角块载荷矩阵
  for (j in 2:k4){
    AAht=bdiag(AAht,Lambda_hat2[[j]])
  }
  AAht=as.matrix(AAht)  ##ppi*m,ri*m dim(AAht)
  ##step2 PCA
  GG=FF_hat[[1]]
  for (jj in 2:k4){
    GG=cbind(GG,FF_hat[[jj]])#TT, m*ri dim(GG)
  }
  Fht=as.matrix(sqrt(TT)*eigen(GG%*%t(GG))$vectors[,1:r],nrow=TT)
  Bht=t(GG)%*%Fht/TT
  ABH=AAht%*%Bht
  return(list("ABH" = ABH, "Fht" = Fht))
}


DPCA <- function(X,r,m,TT){
  N <- ncol(X)
  wd <- c(TT-m*ceiling(TT/(m+1)),rep(ceiling(TT/(m+1)),m))#;wd
  cl <- makeCluster(m+1) 
  clusterSetRNGStream(cl) 
  clusterExport(cl,c("est_PCA1","X","r","m"))
  result <- parSapply(cl,1:(m+1),function(k,wd){#k=1 #函数需要外部参数
    out <- est_PCA1(X[c((sum(wd[1:k])-wd[k]+1):sum(wd[1:k])),],r)
    Lambda_hat <- out$Lambda_hat
    return(list("Lambda_hat" = Lambda_hat))
  },wd)
  stopCluster(cl)
  Sigma <- Reduce("+", lapply(result, function(x) x %*% t(x)))/(m+1)
  Lam_D <- as.matrix(sqrt(N)*eigen(Sigma)$vectors[,1:r],nrow=N)
  FF_D <- X%*%Lam_D%*%solve(t(Lam_D)%*%Lam_D)
  return(list("Lam_D"=Lam_D,"FF_D" = FF_D))
}


DEn_PFA <- function(X,TT,N,r,em,k3,stepp,Lam_em){
  for(k in 1:em){# k=1
    cl <- makeCluster(k3)
    clusterSetRNGStream(cl)
    clusterExport(cl,c("est_PCA","X","r","k3","stepp","N","k"))
    tem_Lam <- parSapply(cl,1:k3,function(i){#i=1
      step <- stepp[-k]                                            
      over <- c((sum(stepp[1:k])-stepp[k]+1):sum(stepp[1:k]))
      ind <- c(1:N)[-over]
      em <- k3+1 #Lambda <- DPCA(X[,c(over,ind[(sum(step[1:i])-step[i]+1):sum(step[1:i])])],r,em)
      x <- X[,c(over,ind[(sum(step[1:i])-step[i]+1):sum(step[1:i])])]
      wd <- nrow(x)/em
      result <- list()
      for(k in 1:em){
        end <- k*wd
        out <- est_PCA(x[((k-1)*wd+1):end,],r)
        result[[k]] <- out$Lambda_hat
      }
      Sigma <- Reduce("+", lapply(result, function(x) x %*% t(x)))/em
      Lambda <- as.matrix(sqrt(ncol(x))*eigen(Sigma)$vectors[,1:r],nrow=N)
      # out1 <- est_PCA1(x,r)
      # Lambda <- out1$Lambda_hat
      return(list("Lambda"=Lambda))
    })
    stopCluster(cl)
    em_Lam[[k]] <- em_splice(tem_Lam,Lam_em,k,k3,stepp)
  }
  align_emLam <- do.call(cbind,em_Lam)#;head(align_emLam)
  Lam_em <- sqrt(N)*(svd(align_emLam)$u)[,1:r] 
  FF_em <- X%*%Lam_em%*%solve(t(Lam_em)%*%Lam_em)
  return(list("Lam_em" = Lam_em, "FF_em" = FF_em))
}

################ Function: the number of factors
#----------------------------------------------------------------------------
get_mode <- function(x) {
  uniq_x <- unique(x)
  tab <- table(x)
  mode_value <-  as.numeric(names(tab)[which.max(tab)])
  return(mode_value)
}

r_PFA <- function(X,k3,stepp){
  #k <- 1  #selecting the first partition as overlap
  TT <- nrow(X)
  N <- ncol(X)
  cl <- makeCluster(k3)
  clusterSetRNGStream(cl)                                              
  clusterExport(cl,c("X","k3","stepp","TT","N"))
  rexc <- parSapply(cl,1:k3,function(i){#i=1
    k <- 1
    step <- stepp[-k]                                             #overlap <- stepp[k]
    over <- c((sum(stepp[1:k])-stepp[k]+1):sum(stepp[1:k]))
    ind <- c(1:N)[-over]
    XX <- X[,c(over,ind[(sum(step[1:i])-step[i]+1):sum(step[1:i])])]
    Ni_ti <- dim(XX)[2]
    eig <- eigen(t(XX)%*%XX/(TT*Ni_ti))
    dd <- eig$values
    K_max <- ceiling(Ni_ti/2)
    ra <- which.min(dd[2:K_max]/dd[1:(K_max-1)])
    return(list("r" = ra))
  })
  stopCluster(cl)  
  return(unlist(rexc))
}

r_PFA_plus <- function(X,k3,stepp){
  N <- ncol(X)
  r <- 2*get_mode(r_PFA(X,k3,stepp))
  em <- k3+1
  em_Lam  <- list()
  Lam_em <- matrix(0,N,r)
  for(k in 1:em){# k=1
    cl <- makeCluster(k3)
    clusterSetRNGStream(cl)
    clusterExport(cl,c("est_PCA1","X","r","k3","stepp","N","k"),envir = environment())
    tem_Lam <- parSapply(cl,1:k3,function(i){
      step <- stepp[-k]                                             #overlap <- stepp[k]
      over <- c((sum(stepp[1:k])-stepp[k]+1):sum(stepp[1:k]))
      ind <- c(1:N)[-over]
      x <- X[,c(over,ind[(sum(step[1:i])-step[i]+1):sum(step[1:i])])]
      eig_X <- eigen(t(x)%*%x/nrow(x))
      Lambda <- sqrt(ncol(x))*eig_X$vectors[,1:r]
      value <- diag(eig_X$values[1:r])
      return(list("Lambda"=Lambda, "value"=value))
    })
    stopCluster(cl)
    em_Lam[[k]] <- em_splice(tem_Lam["Lambda", ],Lam_em,k,k3,stepp)%*%tem_Lam["value", ][[1]]
  }
  align_emLam <- do.call(cbind,em_Lam)
  eig_x <- eigen(t(align_emLam)%*%align_emLam/(N*ncol(align_emLam)))
  ev <- eig_x$values
  kmax <- ceiling(ncol(align_emLam)/2)
  return(which.min(ev[2:kmax]/ev[1:(kmax-1)]))
}
