
#Figure S.3--alpha = 0-4
library(snowfall)  
library(parallel)
library(Matrix)
library(MASS)
##########################
path <- "C:/PFA_code/TT=1000N=2000/n/"
set.seed(0)
n <- 100                                                #sample
seed <- c(1:(n*4)) 
TT <- 1000
N <- 2000; floor(N^(2/5))
J <- 10; rho <- 0.5; beta <- 0.2; theta <- 1
r <- 3
Lam_em <- temp <- lamT <- Lam <- matrix(0,N,r)
em_Lam <- result <- list()
X <- matrix(0,TT,N)
DL_1 <- DF_1 <- DC <- DL_4 <- DF_4 <- DC_exc <-rep(0,n)
a <- 4                                                 #n*(M+1)
DL <- DF <- DC_exc1 <- matrix(0,a,n)
k3 <- m <- 19
em <- m+1
stepp <- c(N-m*ceiling(N/(m+1)),rep(ceiling(N/(m+1)),m));stepp #N_i
Lamem <- matrix(0,N,em*r)
  
    for(i in 1:n){#i=1
      all_Lam <- NULL
      dat <-  data(TT,N,r,J,rho,beta,theta)
      XX <- dat$X 
      L <- dat$Lambda
      
      for(s in 1:a){#s <- 2
      set.seed(seed[(s-1)*n+i])
      index <- sample(1:N)
      for(j in 1:N){
        X[,j] <- XX[,index[j]]
      }
      #------------------------------   
      
      #En-PFA
      for(k in 1:em){# k=1
        cl <- makeCluster(k3)
        clusterSetRNGStream(cl)
        clusterExport(cl,c("est_PCA1","X","r","k3","stepp","N","k"))
        tem_Lam <- parSapply(cl,1:k3,function(i){
          step <- stepp[-k]                                             #overlap <- stepp[k]
          over <- c((sum(stepp[1:k])-stepp[k]+1):sum(stepp[1:k]))
          ind <- c(1:N)[-over]
          out1 <- est_PCA1(X[,c(over,ind[(sum(step[1:i])-step[i]+1):sum(step[1:i])])],r)
          Lambda <- out1$Lambda_hat
          return(list("Lambda"=Lambda))
        })
        stopCluster(cl)
        em_Lam[[k]] <- em_splice(tem_Lam,Lam_em,k,k3,stepp)
      }
    
      temp <- do.call(cbind,em_Lam)                             #head(align_emLam)
      for(p in 1:N){Lamem[index[p],] <- temp[p,]}
      all_Lam <- cbind(all_Lam,Lamem)
      Lam_em <- sqrt(N)*(svd(all_Lam)$u)[,1:r]
      FF_em <- XX%*%Lam_em%*%solve(t(Lam_em)%*%Lam_em)
      DL[s,i] <- D(Lam_em,L,r)
      DF[s,i] <- D(dat$FF,FF_em,r)
      DC_exc1[s,i] <- norm(FF_em%*%t(Lam_em)-dat$FF%*%t(L),"F")/sqrt(TT*N)
      closeAllConnections()
      if(s == 1){
        
        #PFA
        for(p in 1:N){Lam[index[p],] <- em_Lam[[1]][p,]}
        FF <- XX%*%Lam%*%solve(t(Lam)%*%Lam)
        DL_4[i] <- D(L,Lam,r)
        DF_4[i] <- D(dat$FF,FF,r)
        DC_exc[i] <- norm(FF%*%t(Lam)-dat$FF%*%t(L),"F")/sqrt(TT*N)
        print(i)
        
        #PCA
        out <- est_PCA(X,r)
        lam_T <- out$Lambda_hat
        FF <- out$F_hat
        for(p in 1:N){lamT[index[p],] <- lam_T[p,]}
        DL_1[i] <- D(lamT,L,r)
        DF_1[i] <- D(dat$FF,FF,r)
        DC[i] <- norm(FF%*%t(lamT)-dat$FF%*%t(L),"F")/sqrt(TT*N)
        
      }
      #closeAllConnections()
      }
     
    }
  
  write.csv(t(rbind(DL_1,DL_4,DL)),paste0(path,"DL_n","_J",J,"_rho",rho,"out.csv"))
  write.csv(t(rbind(DF_1,DF_4,DF)),paste0(path,"DF_n","_J",J,"_rho",rho,"out.csv"))
  write.csv(t(rbind(DC,DC_exc,DC_exc1)),paste0(path,"CC_n","_J",J,"_rho",rho,"out.csv"))
  
  DDL <- apply(rbind(DL_1,DL_4,DL),1,mean)
  DDF <- apply(rbind(DF_1,DF_4,DF),1,mean)
  CC <- apply(rbind(DC,DC_exc,DC_exc1),1,mean)
  out <- cbind(DDL,DDF,CC,m,rho,J)
  out
  rownames(out) <- c("PCA","PFA","En-PFA(alpha=1)","En-PFA(alpha=2)","En-PFA(alpha=3)","En-PFA(alpha=4)")
  out
  write.csv(out,paste0(path,"T",TT,"N",N,"_J",J,"_rho",rho,"out.csv"))
