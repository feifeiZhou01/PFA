# quantifying the variability across partitions-five boxplots
##suggest
data <- function(TT,N,r,J,rho,beta,theta){
  E <- matrix(0,TT,N)
  v <- mvrnorm(TT, rep(0, N), diag(1,N))
  betav <- apply(cbind(1:N),1,function(i) beta*rowSums(as.matrix(v[,pmax(1,i-J):pmin(i+J,N)])))
  E[1,] <- (1-beta)*v[1,]+betav[1,]
  for (t in 2:TT)E[t,] <- rho*E[t-1,]+(1-beta)*v[t,]+betav[t,]
  U <- sqrt((1-rho^2)/(1+2*J*beta^2))*E
  L <- as.matrix(sqrt(N)*Fregularize(matrix(rnorm(N*r,0,1),N,r),r)) 
  FF <- as.matrix(Lregularize(mvrnorm(TT, rep(0, r), diag(1,r)),r))
  X <- FF%*%t(L)+sqrt(theta)*U
  X <- X - matrix(rep(apply(X,2,mean),TT),nrow=TT,byrow=TRUE)
  return(list(FF=FF,Lambda=L,X=X))
}

library(snowfall)  
library(parallel)
library(Matrix)
library(MASS)
library(ggplot2)
library(patchwork)
##########################
set.seed(3)
rep <- 5
TT <- 1000
N <- 2000
J <- 10; 
rho <- 0.5; beta <- 0.2; theta <- 1
r <- 3
#En-FFA
k3 <- m <- 19
em <- k3+1
temp <- rep(0,em) 
stepp <- c(N-m*ceiling(N/(m+1)),rep(ceiling(N/(m+1)),m));stepp #N_i
DL_4 <- DF_4 <- DC_exc <- matrix(0,rep,em)
X <- matrix(0,TT,N)
aa <- 1#0.25#
DL <- DF <- DC <- matrix(0,rep,length(aa))
for(i in 1:rep){#i=1
  em_Lam  <- list()
  Lam_em <- Lambda <- matrix(0,N,r)
  dat <-  data(TT,N,r,J,rho,beta,theta)
  XX <- dat$X 
  L <- dat$Lambda
  set.seed(i)
  index <- sample(1:N)
  for(j in 1:N){
    X[,j] <- XX[,index[j]]
    Lambda[j,] <- L[index[j],]
  }
  
  #En-PFA
  for(k in 1:em){# k=5
    cl <- makeCluster(k3)
    clusterSetRNGStream(cl)                                              
    clusterExport(cl,c("est_PCA1","X","r","k3","stepp","N","k"))
    tem_Lam <- parSapply(cl,1:k3,function(i){#i=1
      step <- stepp[-k]                                             #overlap <- stepp[k]
      over <- c((sum(stepp[1:k])-stepp[k]+1):sum(stepp[1:k]))
      ind <- c(1:N)[-over]
      out1 <- est_PCA1(X[,c(over,ind[(sum(step[1:i])-step[i]+1):sum(step[1:i])])],r)
      Lambda <- out1$Lambda_hat
      return(list("Lambda"=Lambda))
    })
    stopCluster(cl)  
    em_Lam[[k]] <- em_splice(tem_Lam,Lam_em,k,k3,stepp)
    Lam <- em_Lam[[k]]
    FF <- X%*%Lam%*%solve(t(Lam)%*%Lam)
    DL_4[i,k] <- D(Lambda,Lam,r)
    DF_4[i,k] <- D(dat$FF,FF,r)
    DC_exc[i,k] <- norm(FF%*%t(Lam)-dat$FF%*%t(Lambda),"F")/sqrt(TT*N)
    
    if(k %in% (aa*em)){
      print(k)
      align_emLam <- do.call(cbind,em_Lam)#;head(align_emLam)
      Lam_em <- sqrt(N)*(svd(align_emLam)$u)[,1:r] 
      FF_em <- X%*%Lam_em%*%solve(t(Lam_em)%*%Lam_em)
      DL[i,which(aa*em==k)] <- D(Lambda,Lam_em,r)
      DF[i,which(aa*em==k)] <- D(dat$FF,FF_em,r)
      DC[i,which(aa*em==k)] <- norm(FF_em%*%t(Lam_em)-dat$FF%*%t(Lambda),"F")/sqrt(TT*N)
    }
  }
  closeAllConnections()
}


out <- cbind(DL_7,DF_7,DC_exc1,DL_4,DF_4,DC_exc)
path <- "C:/PFA_code/"
write.csv(out,paste0(path,"TT",TT,"N",N,"J",J,"_rho",rho,"m",m,"box.csv"))

#------------------------------------------------------------
library(ggplot2)
library(reshape2)  

df_long <- melt(DL_4)
colnames(df_long) <- c("Group", "Var", "Value") 
df_long$Method <- "PFA"
df_points <- data.frame(
  Group = 1:nrow(DL_4),
  DL1 = DL,
  Method = "En-PFA"
)

p1 <- ggplot() +
  
  geom_boxplot(
    data = df_long,
    aes(x = factor(Group), y = Value, fill = Method),
    color = "black", size = 0.5
  ) +
 
  geom_point(
    data = df_points, 
    aes(x = factor(Group), y = DL1, color = Method),
    size = 2
  ) +
  scale_y_continuous(
    limits = c(0.03, 0.035),
    breaks = seq(0.03, 0.036, 0.001)
    ,expand = c(0, 0)
  ) +
 
  scale_fill_manual(
    name = NULL,
    values = c("PFA" = "#33A02C")#"#80CDC1"
  ) +
  scale_color_manual(
    name = "Method",
    values = c("En-PFA" = "#FF7F00"),#"#6A3D9A"
    labels = c("En-PFA" = expression("En-PFA"~(alpha==1)))#0.25
  ) +
  labs(x = "seed", y = "DL") +
  theme_minimal()+
  theme(
    panel.border = element_rect(colour = "black", fill = NA, size = 0.5),
    legend.position = "top",
    legend.title = element_text(size = 12),
    legend.text = element_text(size = 8),
    axis.title = element_text(size = 12, face = "bold"),
    axis.text = element_text(size = 12, face = "bold"),
    axis.text.x = element_text(vjust = 1)
  )+
  guides(
    fill = guide_legend(override.aes = list(shape = NA)),  
    color = guide_legend(override.aes = list(shape = 16, size = 2)) 
  )
p1
#----------------------------
df_long <- melt(DF_4)
colnames(df_long) <- c("Group", "Var", "Value")
df_long$Method <- "PFA"
df_points <- data.frame(
  Group = 1:nrow(DF_4),
  DF7 = DF,
  Method = "En-PFA"
)

p2 <- ggplot() +
  geom_boxplot(
    data = df_long,
    aes(x = factor(Group), y = Value, fill = Method),
    color = "black", size = 0.5
  ) +
 
  geom_point(
    data = df_points,
    aes(x = factor(Group), y = DF7, color = Method),
    size = 2
  ) +
  scale_y_continuous(
    limits = c(0.026, 0.032),
    breaks = seq(0.026, 0.032, 0.001)
    ,expand = c(0, 0)
  ) +
 
  scale_fill_manual(
    name = NULL,
    values = c("PFA" = "#33A02C")
  ) +
  scale_color_manual(
    name = "Method",
    values = c("En-PFA" = "#FF7F00"),
    labels = c("En-PFA" = expression("En-PFA"~(alpha==1)))#0.25
  ) +
  labs(x = "seed", y = "DF") +
  theme_minimal()+
  theme(
    panel.border = element_rect(colour = "black", fill = NA, size = 0.5),
    legend.position = "top",
    legend.title = element_text(size = 12),
    legend.text = element_text(size = 8),
    axis.title = element_text(size = 12, face = "bold"),
    axis.text = element_text(size = 12, face = "bold"),
    axis.text.x = element_text(vjust = 1)
  )+
  guides(
    fill = guide_legend(override.aes = list(shape = NA)),  
    color = guide_legend(override.aes = list(shape = 16, size = 2)) 
  )
p2

#----------------------------
df_long <- melt(DC_exc)
colnames(df_long) <- c("Group", "Var", "Value")
df_long$Method <- "PFA"
df_points <- data.frame(
  Group = 1:nrow(DC_exc),
  DC = DC,
  Method = "En-PFA"
)

p3 <- ggplot() +
  
  geom_boxplot(
    data = df_long,
    aes(x = factor(Group), y = Value, fill = Method),
    color = "black", size = 0.5
  ) +
 
  geom_point(
    data = df_points,
    aes(x = factor(Group), y = DC, color = Method),
    size = 2
  ) +
  scale_y_continuous(
    limits = c(0.072, 0.078),
    breaks = seq(0.072, 0.078, 0.001)
    ,expand = c(0, 0)
  ) +

  scale_fill_manual(
    name = NULL,
    values = c("PFA" = "#33A02C")
  ) +
  scale_color_manual(
    name = "Method",
    values = c( "En-PFA" = "#FF7F00"),
    labels = c("En-PFA" = expression("En-PFA"~(alpha==1)))#0.25
  ) +
  labs(x = "seed", y = "MSE-CC") +
  theme_minimal()+
  theme(
    panel.border = element_rect(colour = "black", fill = NA, size = 0.5),
    legend.position = "top",
    legend.title = element_text(size = 12),
    legend.text = element_text(size = 8),
    axis.title = element_text(size = 12, face = "bold"),
    axis.text = element_text(size = 12, face = "bold"),
    axis.text.x = element_text(vjust = 1)
  )+
  guides(
    fill = guide_legend(override.aes = list(shape = NA)),  
    color = guide_legend(override.aes = list(shape = 16, size = 2)) 
  )
p3

library(patchwork)
#path <- "C:/PFA_code/CLF_seed_0.25.pdf"
path <- "C:/PFA_code/CLF_seed_1.pdf"
pdf(path, width = 16, height = 5.5) 
CLF <- p1 + p2 + p3 + plot_layout(ncol = 3)
print(CLF)
dev.off()




