
library(snowfall)  
library(parallel)
library(Matrix)
library(MASS)
##########################
path <- "C:/PFA_code/T=1000N=2000-4000/"
set.seed(0)
n <- 100                          #sample
seed <- c(1:n)                           #sample
rho <- 0.5; beta <- 0.2; theta <- 1
J <- 15
r <- 3
em_Lam <- result <- list()
DL_4 <- DF_4 <- DC_exc <- DL_7 <- DF_7 <- DC_exc1 <- DL_1 <- DF_1 <- DC <- DL_2 <- DF_2 <- DC_Fan <- DL_3 <- DF_3 <- DC_DEn <- numeric(n)
DL_5 <- DF_5 <- DC_Gao1 <- numeric(n)
t_DEn <- t_PCA <- t_PFA <- t_En <- t_Fan <-  t_Gao1 <- numeric(n)
DL_7_a <- DF_7_a <- DC_exc1_a <- t_En_a <- matrix(0,n,3)
out <- NULL
TT <- 1000
for(N in c(2000,3000,4000)){  
  Lambda <- L <- Lam_em <- matrix(0,N,r)
  X <- matrix(0,TT,N)
  m <- 19
  em <- m+1
  stepp <- c(N-m*ceiling(N/(m+1)),rep(ceiling(N/(m+1)),m));stepp #N_i
  for(i in 1:n){#i=1
    
    dat <- data(TT,N,r,J,rho,beta,theta) 
    XX <- dat$X     #a <- t(X)%*%X/TT
    L <- dat$Lambda
    set.seed(seed[i])
    index <- sample(1:N) #index <- c(1:N)
    for(j in 1:N){
      X[,j] <- XX[,index[j]]
      Lambda[j,] <- L[index[j],]
    }
    
    # # #PCA
    # a <- proc.time()
    # out <- est_PCA1(X,r)
    # lam_T <- out$Lambda_hat
    # FF <- out$F_hat
    # b <- proc.time()
    # t_PCA[i] <- (b-a)["elapsed"]
    # DL_1[i] <- D(Lambda,lam_T,r)
    # DF_1[i] <- D(dat$FF,FF,r)
    # DC[i] <- norm(FF%*%t(lam_T)-dat$FF%*%t(Lambda),"F")/sqrt(TT*N)

    # #HFA
    # a <- proc.time()
    # Gao1 <- HFA(X,r,m)
    # b <- proc.time()
    # t_Gao1[i] <- (b-a)["elapsed"]
    # closeAllConnections()
    # DL_5[i] <- D(Lambda,Gao1$ABH,r)
    # DF_5[i] <- D(dat$FF,Gao1$Fht,r)
    # DC_Gao1[i] <- norm(Gao1$Fht%*%t(Gao1$ABH)-dat$FF%*%t(Lambda),"F")/sqrt(TT*N)

   
    # #PFA
    a <- proc.time()
    PF <- PFA(X,r,m,L,stepp)
    Lam <- PF$Lam
    FF <- PF$FF
    b <- proc.time()
    t_PFA[i] <- (b-a)["elapsed"]
    closeAllConnections()
    DL_4[i] <- D(Lambda,Lam,r)
    DF_4[i] <- D(dat$FF,FF,r)
    DC_exc[i] <- norm(FF%*%t(Lam)-dat$FF%*%t(Lambda),"F")/sqrt(TT*N)

    #En-PFA
    a <- proc.time()
    En <- En_PFA(X,r,m,aa=1,Lam_em)#En_PFA(X,r,em,k3,TT,N,Lam_em,stepp)#En_PFA(X,r,em)
    Lam_em <- En$Lam_em
    FF_em <-  En$FF_em
    b <- proc.time()
    t_En[i] <- (b-a)["elapsed"]
    DL_7[i] <- D(Lam_em,Lambda,r)
    DF_7[i] <- D(FF_em,dat$FF,r)
    DC_exc1[i] <- norm(FF_em%*%t(Lam_em)-dat$FF%*%t(Lambda),"F")/sqrt(TT*N)
    closeAllConnections()
    print(i)
    
    # #DP
    # a <- proc.time()
    # Fan <- DPCA(X,r,em,TT)
    # Lam_D <- Fan$Lam_D
    # F_D <- Fan$FF_D
    # b <- proc.time()
    # t_Fan[i] <- (b-a)["elapsed"]
    # DL_2[i] <- D(Lambda,Lam_D,r)
    # DF_2[i] <- D(dat$FF,F_D,r)
    # DC_Fan[i] <- norm(F_D%*%t(Lam_D)-dat$FF%*%t(Lambda),"F")/sqrt(TT*N)


    ##En-PFA-aa

    for(a in 1:3){
      aa <- c(0.1,0.25,0.5)[a]
      em <- aa*(m+1)
      temp <- rep(0,em) #time
      b <- proc.time()
      En <- En_PFA(X,r,m,aa,Lam_em)
      Lam_em <- En$Lam_em
      FF_em <-  En$FF_em
      c <- proc.time()
      t_En_a[i,a] <- (c-b)["elapsed"]
      DL_7_a[i,a] <- D(Lam_em,Lambda,r)
      DF_7_a[i,a] <- D(FF_em,dat$FF,r)
      DC_exc1_a[i,a] <- norm(FF_em%*%t(Lam_em)-dat$FF%*%t(Lambda),"F")/sqrt(TT*N)
      closeAllConnections()
    }
    
    # #DEn-PFA
    # em_Lam <- list()
    # a <- proc.time()
    # DEn <- DEn_PFA(X,TT,N,r,em,k3,stepp,Lam_em)
    # Lam_em <- DEn$Lam_em
    # FF_em <- DEn$FF_em
    # b <- proc.time()
    # t_DEn[i] <- (b-a)["elapsed"]
    # DL_3[i] <- D(Lam_em,Lambda,r)
    # DF_3[i] <- D(FF_em,dat$FF,r)
    # DC_DEn[i] <- norm(FF_em%*%t(Lam_em)-dat$FF%*%t(Lambda),"F")/sqrt(TT*N)
    # closeAllConnections()
  }
  
  Time <- cbind(t_PCA,t_Fan,t_DEn,t_PFA,t_Gao1,t_En,t_En_a)
  DL <- cbind(DL_1,DL_2,DL_3,DL_4,DL_5,DL_7,DL_7_a)
  DF <- cbind(DF_1,DF_2,DF_3,DF_4,DF_5,DF_7,DF_7_a)
  CC <- cbind(DC,DC_Fan,DC_DEn,DC_exc,DC_Gao1,DC_exc1,DC_exc1_a)
  out <- cbind(apply(DL,2,mean),apply(DF,2,mean),apply(CC,2,mean),apply(Time,2,mean))
  rownames(out) <- c("PCA","DP","DEn","PFA","HFA",paste0("En-PFA",c(1,0.1,0.25,0.5)))
  colnames(out) <- c("DL","DF","CC","time")
  print(out)
  
  write.csv(out,paste0(path,"TT",TT,"N",N,"J",J,"_rho",rho,"m",m,"out.csv"))
  write.csv(DL,paste0(path,"TT",TT,"N",N,"J",J,"_rho",rho,"m",m,"DL.csv"))
  write.csv(DF,paste0(path,"TT",TT,"N",N,"J",J,"_rho",rho,"m",m,"DF.csv"))
  write.csv(CC,paste0(path,"TT",TT,"N",N,"J",J,"_rho",rho,"m",m,"CC.csv"))
  write.csv(Time,paste0(path,"TT",TT,"N",N,"J",J,"_rho",rho,"m",m,"time.csv"))
  
}


